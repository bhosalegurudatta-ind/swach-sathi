const mongoose = require('mongoose');

const ComplaintSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  wasteType: {
    type: String,
    enum: ['Wet', 'Dry', 'Plastic', 'Hazardous', 'Other'],
    required: [true, 'Please select a waste type']
  },
  location: {
    type: String,
    required: [true, 'Please provide a location']
  },
  description: {
    type: String
  },
  imageUrl: {
    type: String,
    default: 'no-photo.jpg'
  },
  status: {
    type: String,
    enum: ['Pending', 'Resolved'],
    default: 'Pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Complaint', ComplaintSchema);
