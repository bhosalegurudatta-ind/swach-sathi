const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');
const { protect, authorize, optionalProtect } = require('../middleware/auth');

// @route   GET /api/complaints
router.get('/', optionalProtect, async (req, res) => {
  try {
    let query;
    if (req.user && req.user.role === 'admin') {
      query = Complaint.find().populate('user', 'name email');
    } else if (req.user) {
      query = Complaint.find({ user: req.user.id });
    } else {
      // Public view (maybe just resolved ones or total count)
      query = Complaint.find({ status: 'Resolved' });
    }
    
    const complaints = await query;
    res.status(200).json({ success: true, count: complaints.length, data: complaints });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// @route   POST /api/complaints
router.post('/', protect, async (req, res) => {
  try {
    req.body.user = req.user.id;
    const complaint = await Complaint.create(req.body);
    res.status(201).json({ success: true, data: complaint });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// @route   PUT /api/complaints/:id
router.put('/:id', protect, authorize('admin'), async (req, res) => {
  try {
    let complaint = await Complaint.findById(req.params.id);
    if (!complaint) {
      return res.status(404).json({ success: false, error: 'Complaint not found' });
    }

    complaint = await Complaint.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({ success: true, data: complaint });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

module.exports = router;
