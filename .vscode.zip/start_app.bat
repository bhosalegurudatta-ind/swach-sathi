@echo off
setlocal enabledelayedexpansion

echo ==================================================
echo   Swachh Alandi Smart Waste Ecosystem Startup
echo ==================================================
echo.

:: Check for Node.js
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed! 
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b
)

echo [1/3] Checking dependencies...
if not exist "node_modules\" (
    echo Installing root dependencies...
    call npm install
)
if not exist "backend\node_modules\" (
    echo Installing backend dependencies...
    cd backend && call npm install && cd ..
)

echo.
echo [3/3] Finalizing Setup...
:: Silently call the seed-admin route to ensure the admin account exists
start /b cmd /c "timeout /t 3 >nul && curl -s http://localhost:5000/api/auth/seed-admin >nul"

:: Start the browser after a short delay
start /b cmd /c "timeout /t 5 >nul && start http://localhost:5000"

:: Start the server
npm start

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Server failed to start.
    echo Please check if Port 5000 is already in use.
    pause
)

pause
