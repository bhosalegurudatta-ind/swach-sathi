// ===== LOADING SCREEN =====
window.addEventListener('load', () => {
  // Show help if taking too long (e.g. server offline)
  const helpTimeout = setTimeout(() => {
    const help = document.getElementById('loader-help');
    if (help) help.classList.remove('hidden');
    const status = document.getElementById('loader-status');
    if (status) status.innerText = 'Connection Error';
  }, 6000);

  setTimeout(() => {
    clearTimeout(helpTimeout);
    const loader = document.getElementById('loading-screen');
    if (loader) { loader.classList.add('hide'); setTimeout(() => loader.remove(), 500); }
  }, 800);
});

// ===== TOAST NOTIFICATIONS =====
function showToast(msg, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="fa-solid ${type === 'error' ? 'fa-circle-xmark' : 'fa-circle-check'}"></i> ${msg}`;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 400); }, 3000);
}

// ===== NAVBAR SCROLL EFFECT =====
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  if (nav) nav.classList.toggle('scrolled', window.scrollY > 50);
});

// ===== MOBILE MENU =====
function toggleMobileMenu() {
  document.getElementById('nav-links')?.classList.toggle('open');
}

// ===== HERO PARTICLES =====
function createParticles() {
  const container = document.getElementById('hero-particles');
  if (!container) return;
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.top = Math.random() * 100 + '%';
    p.style.animationDelay = Math.random() * 8 + 's';
    p.style.animationDuration = (6 + Math.random() * 6) + 's';
    p.style.width = p.style.height = (2 + Math.random() * 4) + 'px';
    container.appendChild(p);
  }
}

// ===== ANIMATED STATS COUNTER =====
function animateCounters() {
  const counters = document.querySelectorAll('.stat-number');
  counters.forEach(counter => {
    const target = +counter.getAttribute('data-target');
    if (!target) return;
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    const update = () => {
      current += step;
      if (current < target) {
        counter.innerText = Math.floor(current).toLocaleString();
        requestAnimationFrame(update);
      } else {
        counter.innerText = target.toLocaleString();
      }
    };
    update();
  });
  // Animate stat bars
  document.querySelectorAll('.stat-bar-fill').forEach(bar => {
    const w = bar.style.width;
    bar.style.width = '0';
    setTimeout(() => { bar.style.width = w; }, 200);
  });
}

// Intersection Observer for stats
const statsObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      animateCounters();
      statsObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.3 });

// ===== CHATBOT =====
function toggleChatbot() {
  const body = document.getElementById('chatbot-body');
  const icon = document.getElementById('chatbot-toggle-icon');
  if (!body || !icon) return;
  body.classList.toggle('hidden');
  icon.classList.toggle('fa-chevron-up');
  icon.classList.toggle('fa-chevron-down');
}

function handleChatKeyPress(e) { if (e.key === 'Enter') sendChatMessage(); }

function quickChat(msg) {
  const input = document.getElementById('chat-input-field');
  if (input) input.value = msg;
  sendChatMessage();
}

function sendChatMessage() {
  const input = document.getElementById('chat-input-field');
  const msg = input?.value.trim();
  if (!msg) return;
  appendMessage('user', msg);
  input.value = '';
  setTimeout(() => appendMessage('bot', getBotResponse(msg)), 600);
}

function appendMessage(sender, text) {
  const div = document.getElementById('chat-messages');
  if (!div) return;
  const m = document.createElement('div');
  m.className = `message ${sender}`;
  m.innerText = text;
  div.appendChild(m);
  div.scrollTop = div.scrollHeight;
}

function getBotResponse(msg) {
  const m = msg.toLowerCase();
  const lang = localStorage.getItem('preferredLanguage') || 'en';
  
  const botResponses = {
    en: {
      report: '📸 Go to Dashboard → Report Waste to submit a complaint with location and waste type.',
      pickup: '🚛 Go to Dashboard → Schedule Pickup. Select date, time, waste type and we\'ll handle the rest!',
      hello: '👋 Hello! I\'m Swachh Bot. I can help with reporting waste, scheduling pickups, or finding events!',
      event: '📅 Check the Events section on the homepage for upcoming cleanup drives in Alandi!',
      recycle: '♻️ Use our AI Segregation Assistant on the homepage! Type any item and it\'ll tell you the right bin.',
      admin: '🔐 Admin Panel is at admin.html. You need admin credentials to access it.',
      location: '📍 Check the Map section on the homepage to see waste hotspots in Alandi.',
      contact: '📞 Contact Alandi Municipal Corporation or use our complaint system for immediate assistance.',
      default: '🤔 I can help with: reporting waste, scheduling pickups, recycling info, events, and maps. Try asking about one of these!'
    },
    mr: {
      report: '📸 तक्रार नोंदवण्यासाठी डॅशबोर्ड → कचरा तक्रार वर जा.',
      pickup: '🚛 पिकअप शेड्यूल करण्यासाठी डॅशबोर्ड → पिकअप शेड्यूल वर जा.',
      hello: '👋 नमस्कार! मी स्वच्छ बॉट आहे. मी तुम्हाला कचरा व्यवस्थापनात मदत करू शकतो.',
      event: '📅 आगामी कार्यक्रमांसाठी मुख्यपृष्ठावरील कार्यक्रम विभाग तपासा!',
      recycle: '♻️ आमचा AI सहाय्यक वापरा! कोणत्याही वस्तूचे नाव लिहा आणि तो तुम्हाला योग्य डबा सांगेल.',
      admin: '🔐 अ‍ॅडमिन पॅनेल admin.html वर आहे.',
      location: '📍 आळंदीतील कचरा हॉटस्पॉट पाहण्यासाठी मुख्यपृष्ठावरील नकाशा तपासा.',
      contact: '📞 आळंदी नगरपरिषदेशी संपर्क साधा किंवा आमच्या तक्रार प्रणालीचा वापर करा.',
      default: '🤔 मी तुम्हाला मदत करू शकतो: कचरा तक्रार, पिकअप, रिसायकलिंग माहिती, कार्यक्रम आणि नकाशे.'
    },
    hi: {
      report: '📸 शिकायत सबमिट करने के लिए डैशबोर्ड → कचरा रिपोर्ट पर जाएं।',
      pickup: '🚛 पिकअप शेड्यूल करने के लिए डैशबोर्ड → पिकअप शेड्यूल पर जाएं।',
      hello: '👋 नमस्ते! मैं स्वच्छ बॉट हूँ। मैं कचरा प्रबंधन में आपकी मदद कर सकता हूँ।',
      event: '📅 आगामी कार्यक्रमों के लिए होमपेज पर कार्यक्रम अनुभाग देखें!',
      recycle: '♻️ हमारे AI सहायक का उपयोग करें! किसी भी वस्तु का नाम लिखें और वह आपको सही बिन बताएगा।',
      admin: '🔐 एडमिन पैनल admin.html पर है।',
      location: '📍 आलंदी में कचरा हॉटस्पॉट देखने के लिए होमपेज पर नक्शा देखें।',
      contact: '📞 आलंदी नगर निगम से संपर्क करें या हमारी शिकायत प्रणाली का उपयोग करें।',
      default: '🤔 मैं मदद कर सकता हूँ: कचरा रिपोर्ट, पिकअप, पुनर्चक्रण जानकारी, कार्यक्रम और नक्शे।'
    }
  };

  const r = botResponses[lang];
  if (m.includes('report') || m.includes('complaint') || m.includes('तक्रार') || m.includes('शिकायत')) return r.report;
  if (m.includes('pickup') || m.includes('schedule')) return r.pickup;
  if (m.includes('hello') || m.includes('hi') || m.includes('hey') || m.includes('नमस्कार') || m.includes('नमस्ते')) return r.hello;
  if (m.includes('event') || m.includes('कार्यक्रम')) return r.event;
  if (m.includes('recycle') || m.includes('segregat') || m.includes('वर्गीकरण')) return r.recycle;
  if (m.includes('admin')) return r.admin;
  if (m.includes('location') || m.includes('map') || m.includes('नकाशा') || m.includes('नक्शा')) return r.location;
  if (m.includes('contact') || m.includes('help') || m.includes('मदत')) return r.contact;
  return r.default;
}

// ===== AI WASTE ASSISTANT =====
// Local fallback dataset (works without backend)
const localWasteData = {
  en: {
    'plastic bottle': { type: 'Plastic', method: 'Rinse and place in Plastic/Dry waste recycling bin', icon: 'fa-bottle-water' },
    'banana peel': { type: 'Wet', method: 'Compost bin or wet waste bin. Great for composting!', icon: 'fa-apple-whole' },
    'battery': { type: 'Hazardous', method: '⚠️ E-waste collection center. Never throw in regular bin!', icon: 'fa-car-battery' },
    'cardboard': { type: 'Dry', method: 'Flatten and place in Paper/Cardboard recycling bin.', icon: 'fa-box' },
    'newspaper': { type: 'Dry', method: 'Paper recycling bin. Can be reused for packaging.', icon: 'fa-newspaper' }
  },
  mr: {
    'plastic bottle': { type: 'प्लास्टिक', method: 'धुऊन प्लास्टिक/सुका कचरा रिसायकलिंग बिनमध्ये टाका', icon: 'fa-bottle-water' },
    'banana peel': { type: 'ओला', method: 'खत टोपली किंवा ओल्या कचऱ्याच्या डब्यात टाका. खतासाठी उत्तम!', icon: 'fa-apple-whole' },
    'battery': { type: 'धोकादायक', method: '⚠️ ई-कचरा संकलन केंद्र. नियमित डब्यात कधीही टाकू नका!', icon: 'fa-car-battery' },
    'cardboard': { type: 'सुका', method: 'सपाट करा आणि कागद/कार्डबोर्ड रिसायकलिंग बिनमध्ये ठेवा.', icon: 'fa-box' },
    'newspaper': { type: 'सुका', method: 'कागद रिसायकलिंग बिन. पॅकेजिंगसाठी पुन्हा वापरले जाऊ शकते.', icon: 'fa-newspaper' }
  },
  hi: {
    'plastic bottle': { type: 'प्लास्टिक', method: 'धोकर प्लास्टिक/सूखे कचरे के पुनर्चक्रण बिन में रखें', icon: 'fa-bottle-water' },
    'banana peel': { type: 'गीला', method: 'खाद बिन या गीले कचरे के डिब्बे में डालें। खाद बनाने के लिए बढ़िया!', icon: 'fa-apple-whole' },
    'battery': { type: 'खतरनाक', method: '⚠️ ई-कचरा संग्रह केंद्र। सामान्य बिन में कभी न फेंकें!', icon: 'fa-car-battery' },
    'cardboard': { type: 'सूखा', method: 'चपटा करें और कागज/कार्डबोर्ड रीसाइक्लिंग बिन में रखें।', icon: 'fa-box' },
    'newspaper': { type: 'सूखा', method: 'कागज रीसाइक्लिंग बिन। पैकेजिंग के लिए पुन: उपयोग किया जा सकता है।', icon: 'fa-newspaper' }
  }
};

function quickAnalyze(item) {
  const input = document.getElementById('waste-item');
  if (input) input.value = item;
  // Highlight chip
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  event.target.closest('.chip')?.classList.add('active');
  analyzeWaste();
}

async function analyzeWaste() {
  const input = document.getElementById('waste-item');
  const item = input?.value.trim();
  if (!item) return;

  const resultDiv = document.getElementById('ai-result');
  if (!resultDiv) return;
  resultDiv.innerHTML = '<p><i class="fa-solid fa-spinner fa-spin"></i> Analyzing with AI...</p>';
  resultDiv.classList.remove('hidden');

  // Simulate a brief loading delay
  await new Promise(r => setTimeout(r, 800));

  let result = null;
  // Try backend first
  try {
    const res = await api.segregateWaste(item);
    if (res.success) {
      result = { type: res.data.wasteType, method: res.data.disposalMethod };
    }
  } catch (e) { /* fallback to local */ }

  // Local fallback
  if (!result) {
    const key = item.toLowerCase().trim();
    for (const [k, v] of Object.entries(localWasteData)) {
      if (key.includes(k) || k.includes(key)) { result = v; break; }
    }
  }

  if (!result) result = { type: 'Other', method: 'Check local municipal guidelines or dispose in general waste bin.' };

  const badgeClass = result.type.toLowerCase();
  resultDiv.innerHTML = `
    <h4><i class="fa-solid fa-wand-magic-sparkles"></i> Analysis Complete</h4>
    <p><strong>Item:</strong> ${item}</p>
    <p><strong>Category:</strong> <span class="waste-badge ${badgeClass}">${result.type} Waste</span></p>
    <p><strong>Disposal:</strong> ${result.method}</p>
  `;
  showToast(`Analyzed: ${item} → ${result.type} Waste`);
}

function initAI() {
  const input = document.getElementById('waste-item');
  if (input) {
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') analyzeWaste();
    });
  }
}

// ===== IMPACT CALCULATOR =====
function updateCalculator() {
  const plastic = +document.getElementById('slider-plastic')?.value || 0;
  const paper = +document.getElementById('slider-paper')?.value || 0;
  const food = +document.getElementById('slider-food')?.value || 0;

  document.getElementById('val-plastic').innerText = plastic;
  document.getElementById('val-paper').innerText = paper;
  document.getElementById('val-food').innerText = food;

  // Annual calculations
  const co2 = ((plastic * 0.04 + paper * 0.9 + food * 0.25) * 52).toFixed(1);
  const trees = (co2 / 21).toFixed(1);
  const water = Math.round((plastic * 3 + paper * 10) * 52);
  const landfill = Math.round((plastic * 0.03 + paper + food) * 52);

  document.getElementById('result-co2').innerText = co2 + ' Kg';
  document.getElementById('result-trees').innerText = trees;
  document.getElementById('result-water').innerText = water.toLocaleString() + ' Liters';
  document.getElementById('result-landfill').innerText = landfill + ' Kg';

  // Badge
  const badge = document.getElementById('impact-badge');
  if (badge) {
    if (+co2 > 200) { badge.innerText = '🌟 Eco Champion'; badge.style.background = 'rgba(46,204,113,.25)'; }
    else if (+co2 > 100) { badge.innerText = '🌿 Green Warrior'; badge.style.background = 'rgba(46,204,113,.2)'; }
    else if (+co2 > 30) { badge.innerText = '🌱 Eco Learner'; badge.style.background = 'rgba(46,204,113,.15)'; }
    else { badge.innerText = '🌾 Eco Beginner'; badge.style.background = 'rgba(46,204,113,.1)'; }
  }
}

function initCalculator() {
  // Initial calculation
  updateCalculator();
}

// ===== MOCK EVENTS FALLBACK =====
const mockEventsData = {
  en: [
    { title: '🌊 Indrayani River Cleanup', location: 'Indrayani River Bank, Alandi', description: 'Join 200+ volunteers for a mega river cleanup drive.' },
    { title: '🌳 Tree Plantation Drive', location: 'Alandi Devachi Temple Area', description: 'Plant 500 saplings and make Alandi greener.' }
  ],
  mr: [
    { title: '🌊 इंद्रायणी नदी स्वच्छता', location: 'इंद्रायणी नदीकाठ, आळंदी', description: 'नदी स्वच्छता मोहिमेत २००+ स्वयंसेवकांसह सामील व्हा.' },
    { title: '🌳 वृक्षारोपण मोहीम', location: 'आळंदी देवाची मंदिर परिसर', description: '५०० रोपे लावा आणि आळंदीला अधिक हरित बनवा.' }
  ],
  hi: [
    { title: '🌊 इंद्रायणी नदी स्वच्छता', location: 'इंद्रायणी नदी तट, आलंदी', description: 'नदी स्वच्छता अभियान में 200+ स्वयंसेवकों के साथ जुड़ें।' },
    { title: '🌳 वृक्षारोपण अभियान', location: 'आलंदी देवाची मंदिर क्षेत्र', description: '500 पौधे लगाएं और आलंदी को हरा-भरा बनाएं।' }
  ]
};

function loadEvents() {
  const grid = document.getElementById('events-grid');
  if (!grid) return;
  const lang = localStorage.getItem('preferredLanguage') || 'en';

  (async () => {
    let events = [];
    try { events = await api.getEvents(); } catch (e) {}
    if (!events || events.length === 0) events = mockEventsData[lang];

    grid.innerHTML = events.map(ev => `
      <div class="card event-card">
        <div class="event-date"><i class="fa-solid fa-calendar"></i> ${new Date().toLocaleDateString(lang === 'en' ? 'en-IN' : (lang === 'mr' ? 'mr-IN' : 'hi-IN'), { day: 'numeric', month: 'short', year: 'numeric' })}</div>
        <h3>${ev.title}</h3>
        <div class="event-meta">
          <span><i class="fa-solid fa-location-dot"></i> ${ev.location}</span>
        </div>
        <p>${ev.description}</p>
      </div>
    `).join('');
  })();
}

// ===== MUNICIPAL WORKERS =====
async function loadWorkers() {
  const grid = document.getElementById('workers-grid');
  if (!grid) return;
  const lang = localStorage.getItem('preferredLanguage') || 'en';

  try {
    let workers = await api.getWorkers();
    
    // Fallback data if no workers found
    if (!workers || workers.length === 0) {
      workers = [
        { name: 'Rajesh Kumar', role: 'Sanitation Supervisor', phone: '+91 98765 43210', area: 'Ward 1', image: 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?auto=format&fit=crop&q=80&w=200&h=200' },
        { name: 'Sunita Deshmukh', role: 'Waste Collection Lead', phone: '+91 98765 43211', area: 'Ward 2', image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200&h=200' }
      ];
    }

    grid.innerHTML = workers.map(w => `
      <div class="worker-card animate-fade-in-up">
        <img src="${w.image}" alt="${w.name}" class="worker-image">
        <h3>${w.name}</h3>
        <div class="worker-role">${w.role}</div>
        <div class="worker-area"><i class="fa-solid fa-location-dot"></i> ${w.area}</div>
        <div class="worker-actions">
          <a href="tel:${w.phone}" class="worker-btn btn-call"><i class="fa-solid fa-phone"></i> Call</a>
          <a href="https://wa.me/${w.phone.replace(/\D/g,'')}" target="_blank" class="worker-btn btn-chat"><i class="fa-brands fa-whatsapp"></i> Chat</a>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error('Load workers failed:', err);
  }
}

// ===== TAB SWITCHING (Dashboard/Admin) =====
function switchTab(tabId) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
  document.getElementById(tabId)?.classList.remove('hidden');
  document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
  document.querySelector(`[onclick="switchTab('${tabId}')"]`)?.classList.add('active');
}

function checkAuth() {
  const user = JSON.parse(localStorage.getItem('user'));
  if (!user) window.location.href = 'index.html';
  return user;
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  initAI();
  initCalculator();
  loadEvents();
  loadWorkers();
  initEngagement();
  createParticles();
  if (typeof updateCalculator === 'function') updateCalculator();
  const statsSection = document.getElementById('stats');
  if (statsSection) statsObserver.observe(statsSection);
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
      document.getElementById('nav-links')?.classList.remove('open');
    });
  });
});

// ===== ENGAGEMENT & COMMUNITY =====
async function initEngagement() {
  try {
    // Record view
    await api.recordView();
    loadEngagementData();
  } catch (err) { console.error('Engagement init failed:', err); }
}

async function loadEngagementData() {
  try {
    const data = await api.getEngagement();
    if (data.success) {
      document.getElementById('view-count').innerText = data.views;
      document.getElementById('like-count').innerText = data.likes;
      renderComments(data.comments);
    }
  } catch (err) { console.error('Load engagement failed:', err); }
}

function renderComments(comments) {
  const list = document.getElementById('comments-list');
  if (!list) return;
  list.innerHTML = comments.map(c => `
    <div class="comment-item">
      <div class="comment-author">${c.name}</div>
      <div class="comment-text">${c.text}</div>
      <div class="comment-date">${new Date(c.createdAt).toLocaleDateString()}</div>
    </div>
  `).join('') || '<p style="color:var(--text-muted);padding:1rem;">No comments yet. Be the first!</p>';
}

async function handleLike() {
  try {
    const res = await api.recordLike();
    if (res.success) {
      document.getElementById('like-count').innerText = res.likes;
      document.getElementById('like-icon').style.color = '#e74c3c';
      showToast('❤️ Thank you for liking our app!');
    }
  } catch (err) { showToast(t('toast_server_offline'), 'error'); }
}

function handleShare() {
  const url = window.location.href;
  navigator.clipboard.writeText(url).then(() => {
    showToast('🔗 App link copied to clipboard! Share it with friends.');
  });
}

async function handleCommentSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('comment-name').value;
  const text = document.getElementById('comment-text').value;
  try {
    const res = await api.postComment(name, text);
    if (res.success) {
      showToast('✅ Comment posted!');
      e.target.reset();
      loadEngagementData();
    }
  } catch (err) { showToast(t('toast_server_offline'), 'error'); }
}

