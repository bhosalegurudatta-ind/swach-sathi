const translations = {
  en: {
    brand: "Swachh Alandi",
    home: "Home",
    impact: "Impact",
    ai_segregation: "AI Segregation",
    calculator: "Calculator",
    events: "Events",
    map: "Map",
    dashboard: "Dashboard",
    hero_title: "Smart Waste<br><span class='gradient-text'>Ecosystem</span>",
    hero_subtitle: "AI-powered waste management platform for a cleaner, greener Alandi. Report waste, schedule pickups, and join community events.",
    report_waste: "Report Waste",
    try_ai: "Try AI Assistant",
    impact_title: "Making Alandi <span class='gradient-text'>Cleaner Every Day</span>",
    waste_recycled: "Waste Recycled",
    active_volunteers: "Active Volunteers",
    cleanup_drives: "Cleanup Drives",
    trees_planted: "Trees Planted",
    ai_title: "Smart Waste <span class='gradient-text'>Segregation Assistant</span>",
    ai_placeholder: "Type an item... e.g. plastic bottle",
    analyze: "Analyze",
    calc_title: "Your <span class='gradient-text'>Eco Impact</span>",
    annual_impact: "Your Annual Impact",
    co2_saved: "CO₂ Saved",
    water_saved: "Water Saved",
    landfill_diverted: "Landfill Diverted",
    footer_text: "Smart Waste Ecosystem for a cleaner tomorrow.",
    logout: "Logout",
    admin_panel: "Admin Panel",
    
    // Dashboard Specific
    my_dashboard: "My Dashboard",
    overview: "Overview",
    report_littering: "Report Littering",
    schedule_pickup: "Schedule Pickup",
    submit_event: "Submit Event",
    welcome_user: "Welcome, ",
    activity_summary: "Here's your activity summary.",
    my_complaints: "My Complaints",
    my_pickups: "My Pickups",
    litter_reports: "Litter Reports",
    select_waste_type: "Select Waste Type",
    location_placeholder: "📍 Location (e.g. Near Alandi Bus Stand)",
    description_placeholder: "Description (optional)",
    submit_report: "Submit Report",
    privacy_mode_note: "Privacy mode active — faces will be blurred automatically",
    upload_report: "Upload & Report",
    pickup_address: "📍 Pickup Address",
    event_title_placeholder: "Event Title",
    
    // Toasts & Alerts
    toast_logged_in: "✅ Logged in!",
    toast_registered: "✅ Registered!",
    toast_complaint_success: "✅ Complaint submitted!",
    toast_litter_success: "✅ Litter report submitted! Faces blurred.",
    toast_pickup_success: "✅ Pickup scheduled!",
    toast_event_success: "✅ Event submitted for review!",
    toast_server_offline: "❌ Server offline. Please run 'start_app.bat' to start the system.",
    
    // Community Hub
    community_title: "Connect & <span class='gradient-text'>Make a Difference</span>",
    total_views: "Total Views",
    likes: "Likes",
    share: "Share App",
    community_feedback: "Community Feedback",
    
    // Statuses & UI Text
    status: "Status",
    resolved: "Resolved",
    pending: "Pending",
    requested: "Requested",
    assigned: "Assigned",
    verify: "Verify",
    by: "By",
    done: "Done",
    unknown: "Unknown",
    
    // Admin Specific
    admin_menu: "🛡️ Admin Menu",
    analytics: "Analytics",
    manage_complaints: "Manage Complaints",
    manage_pickups: "Manage Pickups",
    manage_litters: "Manage Litters",
    manage_events: "Manage Events",
    total_users: "Total Users",
    pending_tasks: "Pending Tasks",
    resolved_cases: "Resolved Cases",
    community_score: "Community Score",
    workers_badge: "👷 Municipal Team",
    workers_title: "Contact Our <span class='gradient-text'>Service Heroes</span>",
    workers_subtitle: "Directly contact the municipal workers responsible for your area for quick resolution.",
    waste_distribution: "Waste Type Distribution",
    monthly_trend: "Monthly Trend",
    total_complaints: "Total Complaints",
    pending_verification: "Pending Verification",
    verified: "Verified",
    assigned_status: "Assigned",
    requested_status: "Requested"
  },
  mr: {
    brand: "स्वच्छ आळंदी",
    home: "मुख्यपृष्ठ",
    impact: "प्रभाव",
    ai_segregation: "AI वर्गीकरण",
    calculator: "कॅल्क्युलेटर",
    events: "कार्यक्रम",
    map: "नकाशा",
    dashboard: "डॅशबोर्ड",
    hero_title: "स्मार्ट कचरा<br><span class='gradient-text'>व्यवस्थापन</span>",
    hero_subtitle: "स्वच्छ आणि हरित आळंदीसाठी AI-आधारित कचरा व्यवस्थापन प्लॅटफॉर्म. कचऱ्याची तक्रार करा आणि पिकअप शेड्यूल करा.",
    report_waste: "कचऱ्याची तक्रार करा",
    try_ai: "AI सहाय्यक वापरा",
    impact_title: "आळंदीला <span class='gradient-text'>दररोज स्वच्छ करणे</span>",
    waste_recycled: "कचरा रिसायकल",
    active_volunteers: "सक्रीय स्वयंसेवक",
    cleanup_drives: "स्वच्छता मोहीम",
    trees_planted: "लावलेली झाडे",
    ai_title: "स्मार्ट कचरा <span class='gradient-text'>वर्गीकरण सहाय्यक</span>",
    ai_placeholder: "वस्तूचे नाव लिहा... उदा. प्लास्टिक बाटली",
    analyze: "तपासा",
    calc_title: "तुमचा <span class='gradient-text'>पर्यावरण प्रभाव</span>",
    annual_impact: "तुमचा वार्षिक प्रभाव",
    co2_saved: "CO₂ वाचवला",
    water_saved: "पाणी वाचवले",
    landfill_diverted: "डंपिंग टाळले",
    footer_text: "उद्याच्या स्वच्छतेसाठी स्मार्ट कचरा व्यवस्थापन.",
    logout: "लॉगआउट",
    admin_panel: "अ‍ॅडमिन पॅनेल",

    // Dashboard Specific
    my_dashboard: "माझा डॅशबोर्ड",
    overview: "आढावा",
    report_littering: "कचऱ्याची माहिती द्या",
    schedule_pickup: "पिकअप शेड्यूल करा",
    submit_event: "कार्यक्रमाची माहिती द्या",
    welcome_user: "स्वागत आहे, ",
    activity_summary: "येथे तुमच्या कामाचा आढावा आहे.",
    my_complaints: "माझ्या तक्रारी",
    my_pickups: "माझे पिकअप्स",
    litter_reports: "कचरा अहवाल",
    select_waste_type: "कचऱ्याचा प्रकार निवडा",
    location_placeholder: "📍 ठिकाण (उदा. आळंदी बस स्टँड जवळ)",
    description_placeholder: "वर्णन (पर्यायी)",
    submit_report: "तक्रार नोंदवा",
    privacy_mode_note: "गोपनीयता मोड सक्रिय — चेहरे स्वयंचलितपणे अस्पष्ट केले जातील",
    upload_report: "अपलोड आणि तक्रार करा",
    pickup_address: "📍 पिकअप पत्ता",
    event_title_placeholder: "कार्यक्रमाचे नाव",

    // Toasts & Alerts
    toast_logged_in: "✅ लॉगिन यशस्वी!",
    toast_registered: "✅ नोंदणी यशस्वी!",
    toast_complaint_success: "✅ तक्रार नोंदवली!",
    toast_litter_success: "✅ कचरा अहवाल यशस्वी! चेहरे अस्पष्ट केले आहेत.",
    toast_pickup_success: "✅ पिकअप शेड्यूल झाले!",
    toast_event_success: "✅ कार्यक्रम पुनरावलोकनासाठी सबमिट केला!",
    toast_server_offline: "❌ सर्व्हर ऑफलाइन. कृपया सिस्टिम सुरू करण्यासाठी 'start_app.bat' चालवा.",

    // Community Hub
    community_title: "जोडले जा आणि <span class='gradient-text'>बदल घडवा</span>",
    total_views: "एकूण दर्शक",
    likes: "लाईक्स",
    share: "अ‍ॅप शेअर करा",
    community_feedback: "समुदाय अभिप्राय",

    // Statuses & UI Text
    status: "स्थिती",
    resolved: "निकाली काढले",
    pending: "प्रलंबित",
    requested: "विनंती केली",
    assigned: "नियुक्त",
    verify: "तपासा",
    by: "द्वारे",
    done: "यशस्वी",
    unknown: "अज्ञात",

    // Admin Specific
    admin_menu: "🛡️ अ‍ॅडमिन मेनू",
    analytics: "विश्लेषण",
    manage_complaints: "तक्रारी व्यवस्थापित करा",
    manage_pickups: "पिकअप व्यवस्थापित करा",
    manage_litters: "कचरा अहवाल व्यवस्थापित करा",
    manage_events: "कार्यक्रम व्यवस्थापित करा",
    total_users: "एकूण वापरकर्ते",
    pending_tasks: "प्रलंबित कामे",
    resolved_cases: "निकाली काढलेली प्रकरणे",
    community_score: "समुदाय धावसंख्या",
    workers_badge: "👷 नगरपरिषद टीम",
    workers_title: "आमच्या <span class='gradient-text'>सेवा नायकांशी</span> संपर्क साधा",
    workers_subtitle: "जलद निराकरणासाठी तुमच्या क्षेत्रासाठी जबाबदार असलेल्या नगरपरिषद कर्मचाऱ्यांशी थेट संपर्क साधा.",
    waste_distribution: "कचरा प्रकार वितरण",
    monthly_trend: "मासिक कल",
    total_complaints: "एकूण तक्रारी",
    pending_verification: "पडताळणी प्रलंबित",
    verified: "पडताळणी पूर्ण",
    assigned_status: "नियुक्त",
    requested_status: "विनंती केली"
  },
  hi: {
    brand: "स्वच्छ आलंदी",
    home: "होम",
    impact: "प्रभाव",
    ai_segregation: "AI पृथक्करण",
    calculator: "कैलकुलेटर",
    events: "कार्यक्रम",
    map: "नक्शा",
    dashboard: "डैशबोर्ड",
    hero_title: "स्मार्ट कचरा<br><span class='gradient-text'>पारिस्थितिकी</span>",
    hero_subtitle: "स्वच्छ और हरित आलंदी के लिए AI-संचालित कचरा प्रबंधन। कचरे की रिपोर्ट करें और पिकअप शेड्यूल करें।",
    report_waste: "कचरा रिपोर्ट करें",
    try_ai: "AI सहायक का उपयोग करें",
    impact_title: "आलंदी को <span class='gradient-text'>हर दिन स्वच्छ बनाना</span>",
    waste_recycled: "पुनर्नवीनीकरण कचरा",
    active_volunteers: "सक्रिय स्वयंसेवक",
    cleanup_drives: "स्वच्छता अभियान",
    trees_planted: "लगाए गए पेड़",
    ai_title: "स्मार्ट कचरा <span class='gradient-text'>पृथक्करण सहायक</span>",
    ai_placeholder: "वस्तु का नाम लिखें... जैसे प्लास्टिक की बोतल",
    analyze: "विश्लेषण करें",
    calc_title: "आपका <span class='gradient-text'>पर्यावरण प्रभाव</span>",
    annual_impact: "आपका वार्षिक प्रभाव",
    co2_saved: "CO₂ की बचत",
    water_saved: "पानी की बचत",
    landfill_diverted: "लैंडफिल से बचाव",
    footer_text: "बेहतर कल के लिए स्मार्ट कचरा पारिस्थितिकी तंत्र।",
    logout: "लॉगआउट",
    admin_panel: "एडमिन पैनल",

    // Dashboard Specific
    my_dashboard: "मेरा डैशबोर्ड",
    overview: "अवलोकन",
    report_littering: "कचरा रिपोर्ट करें",
    schedule_pickup: "पिकअप शेड्यूल करें",
    submit_event: "कार्यक्रम सबमिट करें",
    welcome_user: "स्वागत है, ",
    activity_summary: "यहाँ आपकी गतिविधि का सारांश है।",
    my_complaints: "मेरी शिकायतें",
    my_pickups: "मेरे पिकअप",
    litter_reports: "कचरा रिपोर्ट",
    select_waste_type: "कचरे का प्रकार चुनें",
    location_placeholder: "📍 स्थान (जैसे आलंदी बस स्टैंड के पास)",
    description_placeholder: "विवरण (वैकल्पिक)",
    submit_report: "रिपोर्ट सबमिट करें",
    privacy_mode_note: "गोपनीयता मोड सक्रिय — चेहरे अपने आप धुंधले हो जाएंगे",
    upload_report: "अपलोड और रिपोर्ट करें",
    pickup_address: "📍 पिकअप का पता",
    event_title_placeholder: "कार्यक्रम का शीर्षक",

    // Toasts & Alerts
    toast_logged_in: "✅ लॉगिन सफल!",
    toast_registered: "✅ पंजीकरण सफल!",
    toast_complaint_success: "✅ शिकायत दर्ज की गई!",
    toast_litter_success: "✅ कचरा रिपोर्ट सफल! चेहरे धुंधले कर दिए गए हैं।",
    toast_pickup_success: "✅ पिकअप शेड्यूल हो गया!",
    toast_event_success: "✅ कार्यक्रम समीक्षा के लिए सबमिट किया गया!",
    toast_server_offline: "❌ सर्वर ऑफलाइन। सिस्टम शुरू करने के लिए कृपया 'start_app.bat' चलाएं।",

    // Community Hub
    community_title: "जुड़ें और <span class='gradient-text'>बदलाव लाएं</span>",
    total_views: "कुल दृश्य",
    likes: "पसंद",
    share: "ऐप साझा करें",
    community_feedback: "सामुदायिक प्रतिक्रिया",

    // Statuses & UI Text
    status: "स्थिति",
    resolved: "सुलझाया गया",
    pending: "लंबित",
    requested: "अनुरोध किया",
    assigned: "नियुक्त",
    verify: "सत्यापित करें",
    by: "द्वारा",
    done: "पूर्ण",
    unknown: "अज्ञात",

    // Admin Specific
    admin_menu: "🛡️ एडमिन मेनू",
    analytics: "एनालिटिक्स",
    manage_complaints: "शिकायतें प्रबंधित करें",
    manage_pickups: "पिकअप प्रबंधित करें",
    manage_litters: "कचरा रिपोर्ट प्रबंधित करें",
    manage_events: "कार्यक्रम प्रबंधित करें",
    total_users: "कुल उपयोगकर्ता",
    pending_tasks: "लंबित कार्य",
    resolved_cases: "सुलझाए गए मामले",
    community_score: "सामुदायिक स्कोर",
    workers_badge: "👷 नगर निगम टीम",
    workers_title: "हमारे <span class='gradient-text'>सेवा नायकों</span> से संपर्क करें",
    workers_subtitle: "त्वरित समाधान के लिए अपने क्षेत्र के जिम्मेदार नगर निगम कर्मियों से सीधे संपर्क करें।",
    waste_distribution: "कचरा प्रकार वितरण",
    monthly_trend: "मासिक रुझान",
    total_complaints: "कुल शिकायतें",
    pending_verification: "सत्यापन लंबित",
    verified: "सत्यापित",
    assigned_status: "नियुक्त",
    requested_status: "अनुरोध किया"
  }
};

function setLanguage(lang) {
  localStorage.setItem('preferredLanguage', lang);
  document.documentElement.lang = lang;
  
  const elements = document.querySelectorAll('[data-i18n]');
  elements.forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang][key]) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = translations[lang][key];
      } else {
        el.innerHTML = translations[lang][key];
      }
    }
  });

  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('onclick').includes(lang));
  });
}

// Helper to get translation in JS
function t(key) {
  const lang = localStorage.getItem('preferredLanguage') || 'en';
  return translations[lang][key] || key;
}

// Initialize language on load
document.addEventListener('DOMContentLoaded', () => {
  const savedLang = localStorage.getItem('preferredLanguage') || 'en';
  setLanguage(savedLang);
});
